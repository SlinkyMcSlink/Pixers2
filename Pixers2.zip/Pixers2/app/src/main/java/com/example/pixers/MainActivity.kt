package com.example.pixers

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val square = object {
            var center = ""
            var topLeft = ""
            var topRight = ""
            var bottomLeft = ""
            var bottomRight = ""
            var orange = false
            var hasPiece = false
            var img = ""
        }

        val piece = {
            var isRed = true
            var currentPosition = ""
            var king = false

            fun kingMe() {
                king = true
            }



        }

    }
}
